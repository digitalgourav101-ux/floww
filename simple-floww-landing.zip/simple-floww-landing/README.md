# Simple Floww Landing Page

A responsive React + Vite landing page for Simple Floww, featuring cinematic CSS animations, WhatsApp API messaging, chatbot automation, CRM and lead management, white-label SaaS, pricing enquiry cards, FAQ accordion, and a mobile navigation menu.

## Run locally

1. Install Node.js (LTS).
2. Open a terminal in this folder.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the local URL shown by Vite (usually http://localhost:5173).

## Build for production

Run `npm run build`, then optionally `npm run preview`.

## Contact configuration

The WhatsApp contact is configured in `src/main.jsx` using the international number `919992596561`, corresponding to 9992596561 in India. Update `WA_NUMBER` there if the business number changes.

## Notes

- Pricing is presented as enquiry-based because verified plan prices were not supplied.
- Google Fonts are loaded remotely; system fallback fonts are provided by the browser.
- Forms have not been added as a fake backend integration. WhatsApp CTAs are functional links.
